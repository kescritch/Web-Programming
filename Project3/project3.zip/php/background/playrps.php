<!-- The computer part of the rock paper scissors page -->
<?php

    
    $computer;
    $rand = rand(1,3);

    if($rand == 1)
    {
        $computer = "Rock";
    }
    elseif($rand == 2)
    {
        $computer = "Paper";
    }
    else
    {
        $computer = "Scissors";
    }
