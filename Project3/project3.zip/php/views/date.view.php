<!-- The viewing page for date and time -->
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../css/styles.css">
    <title>Document</title>
</head>

<body>
    <header><h1>Date And Time</h1></header>
    <div class = "link"><a href="index.view.php">Index</a></div>

    <?php
    require("../background/date.php");
    ?>
</body>
</html>
