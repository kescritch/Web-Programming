<!-- The viewing page for the index -->
<!DOCTYPE html>

<head>
    <link rel="stylesheet" href="../../css/styles.css">
    <title>Index</title>
</head>

<body>
    <header>
        <h1>Index:</h1>
    </header>

    <section>
            <ul>
                <li><a href="date.view.php">Date</a></li>
                <li><a href="rps.view.php">Play Rock Paper Scissors</a></li>
                <li><a href="repeater.view.php">Repeater</a></li>
                <li><a href="../background/logout.php">Logout</a></li>
            </ul>
        </form>
    </section>
</body>

</html>


<?php
    include("../background/authenticator.php");
?>