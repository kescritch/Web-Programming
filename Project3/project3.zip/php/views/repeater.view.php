<!-- The viewing page for the repeater -->
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../../css/styles.css">
    <title>Document</title>
</head>

<body>
    <header><h1>Repeater</h1></header>

    <section>
        <div class = "link"><a href="index.view.php">Index</a></div>
    </section>
</body>
</html>
<?php
    require("../background/repeater.php");
?>